#ifndef STEGA_H_
# define STEGA_H_
#endif /* !STEGA_H_ */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

typedef struct pixel pixel;
struct pixel
{

    int blue;
    int red;
    int green;
};

char *itobi(char c);

int add_char(int c, char *s,size_t i);

void code (char *s, char *source, char *destination);

char *pix_to_bit (int val);

void help_user();

char *decode (char *name);

char *bitoi(char*s,int taille);

int    main (int argc , char **argv);

void write_file(char *s, char * f);
