#include"stega.h"

/* itobi transform a char into string of bit */
char *itobi(char c)
{
  int i;
  char *s;
  s = calloc(1,8);
  i = 8;
  while (c >=1)
    {
      s[i] = c%2 + '0';
      c = c/2;
      i--;
    }
  while (i!=-1)
  {
    s[i]='0';
    i--;
  }
  return s ;
}
/*char *filetostr(char *s)
{
  FILE *src;
  char *res;
  char c;
  int i = 0;
  src = fopen(s,"r");
  res = calloc(1,2000);
  for (c = 0;c != -1;i++)
    {
      c = getc(src);
      res[i]= c;
   }
  return res;
}
*/

/* bitoi transform a string of bit into string of char */
char *bitoi(char*s,int length)
{
  int j = 0;
  int i;
  char c = 0;
  char *new;
  new=calloc(1,length + 1);
  for(i=0;i != length + 1;i++)
  {
    if (i <= 8)
    {
      if (i == 8)
      {
	new[j] = (c*2) +(s[i]-'0');
	j++;
	c = 0;
      }
      else
	c = c*2 +(s[i]-'0');
    }
    else
    {
      if (i%9==0 && i!=9)
      {
	new[j] = c;
	j++;
	c = 0;
      }
      else
	c = c*2 +(s[i]-'0');
    }
  }
  return new;
}

/* add_char return the char corresponding to the new bmp */

int add_char(int c, char *s,size_t i)
{
  size_t length_s;
  length_s = strlen(s);
  if (i < length_s && s[i] == '0' )
  {
    if (c%2 == 0)
    {
      return (c) % 255;

	}
    else
    {
      if (c == 255)
      {
	return(c - 1);
      }
      else
      {
	return (c + 1);
      }
    }
  }
  else
  {
    if (i < length_s && s[i] == '1')
    {
      if (c%2 == 1)
      {
	return (c);
	  }
      else
      {
	if (c == 255)
	{
       	  return(c - 1);
	}
	else
	{
	  return (c + 1);
	}
      }
    }
    else
      if (i >= length_s && i < length_s + 3)
	return -1;
      else
	return c;
  }
}
/* code put the string into the picture */
void code (char *s, char *source, char *destination)
{
  FILE *src;
  FILE *dst;
  pixel p;
  int c;
  size_t i;
  int accu;
  accu = 54;
  p.blue = 0;
  p.red = 0;
  p.green = 0;
  src = fopen(source,"r");
  dst = fopen(destination,"w+");
  c = 1;
  i=0;

  for (accu = 0;accu != 54;accu++)
  {

    c = getc(src);
    putc(c,dst);
  }
  while (p.blue != -1||p.green != -1 ||p.red != -1 )
  {
    p.blue = getc(src);
    if (p.blue == -1)
      break;
    p.green = getc(src);
    if (p.green == -1)
      break;
    p.red = getc(src);
    if (p.red == -1)
      break;
    putc( add_char(p.blue,s,i++),dst);
    putc(add_char(p.green,s,i++),dst);
    putc(add_char(p.red,s,i++),dst);
  }
  fclose (src);
  fclose (dst);
}

/* pix_to_bit transform an int into a string */
char *pix_to_bit (int val)
{
  if(val % 2 == 0)
  {
    return("0");
      }
  else
  {
    return("1");
  }
}
/* decode return the string which is in the picture */
char *decode (char *name)
{
  FILE *src;
  char *res;
  int go_print;
  int jump ;
  int bit_uncoded ;
  pixel bit_coded ;
  res = calloc(1,1);
  go_print = 1;
  jump = 0;
  bit_coded.blue=0;
  bit_coded.green = 0;
  bit_coded.red = 0;
  src = fopen(name,"r");
  for(jump = 0;jump != 54;jump++)
  {
    bit_uncoded = getc(src);
   }
  while(go_print)
  {
    bit_coded.blue = getc(src);
    bit_coded.green = getc(src);
    bit_coded.red = getc(src);
    if(bit_coded.blue == 255 && bit_coded.green == 255 && bit_coded.red == 255)
    {
      go_print = 0;
    }
    else
    {
      res = strcat(res,pix_to_bit(bit_coded.blue));
      res = strcat(res,pix_to_bit(bit_coded.green));
      res = strcat(res,pix_to_bit(bit_coded.red));
    }
  }
  fclose(src);
  return(res);
}

void help_user()
{
  int i;
  printf("\n \n \n");
  printf("===============================================================\n");
  printf("  Aide d'utilisation du module Steganographie du Projet Nigma \n");
  printf("======================by Crypteam==============================\n\n\n");
  printf("1. Encodage\n2. Decodage\n\n");
  printf("Veuillez entrer le numero de la section a consulter: ");
  i = scanf("%1i",&i);
  if (i == 1)
  {
    printf("\n1. L'encodage -e :\n \n");
    printf("La fonctionnalite encodage du module steganographie\n");
    printf("prend en parametre l'information a cacher, le nom du\n");
    printf("fichier qui servira de support (format bmp) et le nom\n");
    printf("du fichier (format bmp) qui sera cree a l'issue de l'execution.\n \n");
    printf("Exemple : ./stegano -e 42 src.bmp dst.bmp\n \n");
  }
  else
  {
    if (i == 2)
    {
      printf("\n2. Le decodage -d :\n \n");
      printf("La fonctionnalite decodage du module steganographie\n");
      printf("prend en parametre le fichier (format bmp) dans lequel\n");
      printf("est cache l'information que l'utilisateur souhaite recuperer.\n \n");
      printf("Exemple : ./stegano -d dst.bmp\n \n");
    }
  }
}

void write_file(char *s, char * f)
{
  FILE * dst;
  int i;
  f =strcat(f,"_decode");
  dst=fopen(f,"w+");
  for (i=0;s[i];i++)
  {
    putc(s[i],dst);
  }
  putc('\n',dst);
  fclose(dst);
}

int main (int argc , char **argv)
{
  size_t i;
  char *s;
  char *bi;
  s = calloc(1,1);
  argc = argc;
  if (argc>1)
  {
    if (strcmp(argv[1],"-e") == 0)
    {

      bi = argv[2];
      for(i = 0;i != strlen(argv[2]);i++)
	s = strcat(s,itobi(bi[i]));
      code(s,argv[3],argv[4]);
      free(s);
    }
    else
    {
      if (strcmp(argv[1],"-d") == 0)
      {
	s = decode(argv[2]);
	s = bitoi(s,strlen(s));
	write_file(s,argv[2]);
	printf("L'information cache dans l'image est : %s \n",s);
	free(s);
      }
      else
	printf("Ne donner aucun argument pour consulter l'aide utilisateur.\n");
    }
  }
  else
  {
    help_user();
  }
  return 0;

}

